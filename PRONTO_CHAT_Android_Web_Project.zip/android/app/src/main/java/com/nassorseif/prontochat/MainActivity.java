package com.nassorseif.prontochat;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText phoneInput, codeInput;
    private TextView status;
    private String verificationId;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        layout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        TextView title = new TextView(this);
        title.setText("PRONTO CHAT");
        title.setTextSize(28);
        title.setPadding(0, 0, 0, 24);
        layout.addView(title);

        phoneInput = new EditText(this);
        phoneInput.setHint("Namba ya simu, mfano +2557XXXXXXXX");
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        layout.addView(phoneInput);

        Button send = new Button(this);
        send.setText("Tuma OTP");
        layout.addView(send);
        send.setOnClickListener(v -> sendOtp());

        codeInput = new EditText(this);
        codeInput.setHint("Ingiza OTP");
        codeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(codeInput);

        Button verify = new Button(this);
        verify.setText("Thibitisha OTP");
        layout.addView(verify);
        verify.setOnClickListener(v -> verifyOtp());

        status = new TextView(this);
        status.setPadding(0, 24, 0, 0);
        layout.addView(status);
        setContentView(layout);
    }

    private void sendOtp() {
        String phone = phoneInput.getText().toString().trim();
        if (!phone.startsWith("+")) {
            status.setText("Tumia mfumo wa kimataifa, mfano +255...");
            return;
        }
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone).setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
            .setActivity(this).setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override public void onVerificationCompleted(PhoneAuthCredential credential) {
                    auth.signInWithCredential(credential).addOnCompleteListener(t -> {
                        if (t.isSuccessful()) saveUser(phone);
                    });
                }
                @Override public void onVerificationFailed(FirebaseException e) {
                    status.setText("Imeshindikana kutuma OTP: " + e.getMessage());
                }
                @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token) {
                    verificationId = id;
                    status.setText("OTP imetumwa. Angalia SMS zako.");
                }
            }).build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void verifyOtp() {
        String code = codeInput.getText().toString().trim();
        if (verificationId == null || code.isEmpty()) {
            status.setText("Omba OTP kwanza kisha ingiza namba ya OTP.");
            return;
        }
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        auth.signInWithCredential(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) saveUser(task.getResult().getUser().getPhoneNumber());
            else status.setText("OTP si sahihi au muda wake umeisha.");
        });
    }

    private void saveUser(String phone) {
        String uid = auth.getCurrentUser().getUid();
        Map<String, Object> user = new HashMap<>();
        user.put("uid", uid);
        user.put("phone", phone);
        user.put("createdAt", com.google.firebase.Timestamp.now());
        db.collection("users").document(uid).set(user)
            .addOnSuccessListener(v -> status.setText("Umeingia PRONTO CHAT kwa mafanikio!"))
            .addOnFailureListener(e -> status.setText("Umeingia, lakini kuhifadhi wasifu kumeshindikana: " + e.getMessage()));
    }
}

# PRONTO CHAT — Mradi wa mwanzo

Mradi huu una sehemu mbili:
- `android/` — chanzo cha Android (Java)
- `website/` — tovuti ya Firebase (HTML/JavaScript)

## Muhimu kabla ya kutumia
Huu ni **mradi wa chanzo**, si APK iliyokwisha kusakinishwa. Ili kutoa APK, mradi wa Android lazima ujengwe kwa Android Studio/Gradle na ujaribiwe kwenye kifaa.

## Android
1. Fungua folda `android` kwa Android Studio.
2. Faili `app/google-services.json` tayari limewekwa.
3. Subiri Gradle Sync.
4. Hakikisha SHA-1 na SHA-256 za cheti cha app zimeongezwa Firebase Console > Project settings > Your apps > Android.
5. Firebase Console > Authentication > Sign-in method: washa Phone.
6. Firebase Console > Authentication > Settings: ruhusu nchi ya Tanzania (+255), ikiwa country allowlist inatumika.
7. Firebase Console > Firestore Database > Rules: weka rules kutoka `firestore.rules`.
8. Build > Build APK(s).

## Website
1. Fungua `website/index.html` kwenye browser kwa majaribio ya UI tu; Phone Auth ya Firebase inahitaji website itumike kwenye domain iliyoidhinishwa (localhost au domain yako).
2. Firebase Console > Project settings > Your apps > Web app: nakili web config halisi na uweke kwenye `website/firebase-config.js`.
3. Firebase Console > Authentication > Settings > Authorized domains: ongeza domain ya tovuti.
4. Deploy kwa Firebase Hosting ukitumia Firebase CLI.

## Usalama
- Firebase API keys za client si nywila, lakini usizichapishe hadharani bila sababu.
- Firestore rules ni msingi wa kuanzia; kagua na ujaribu kabla ya matumizi halisi.
- Usitume OTP, password, au private keys kwa mtu yeyote.

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const statusEl = document.getElementById("status");
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
let confirmation = null;
let verifier = null;

document.getElementById("send").addEventListener("click", async () => {
  try {
    const phone = document.getElementById("phone").value.trim();
    if (!phone.startsWith("+")) throw new Error("Tumia namba ya kimataifa, mfano +2557XXXXXXXX.");
    if (!verifier) verifier = new RecaptchaVerifier(auth, "recaptcha-container", { size: "normal" });
    confirmation = await signInWithPhoneNumber(auth, phone, verifier);
    statusEl.textContent = "OTP imetumwa. Angalia SMS zako.";
  } catch (e) { statusEl.textContent = "Hitilafu: " + e.message; }
});

document.getElementById("verify").addEventListener("click", async () => {
  try {
    if (!confirmation) throw new Error("Bonyeza Tuma OTP kwanza.");
    const code = document.getElementById("code").value.trim();
    const result = await confirmation.confirm(code);
    statusEl.textContent = "Umeingia PRONTO CHAT: " + (result.user.phoneNumber || "");
  } catch (e) { statusEl.textContent = "OTP haijathibitishwa: " + e.message; }
});

// WEKA hapa Firebase Web App config halisi kutoka Firebase Console.
// Usitumie config ya Android. Fungua Project settings > Your apps > Web app.
export const firebaseConfig = {
  apiKey: "WEKA_WEB_API_KEY",
  authDomain: "pronto-chat-90f39.firebaseapp.com",
  projectId: "pronto-chat-90f39",
  storageBucket: "pronto-chat-90f39.firebasestorage.app",
  messagingSenderId: "471525837902",
  appId: "WEKA_WEB_APP_ID"
};
